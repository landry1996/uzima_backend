package com.uzima.domain.message.port;

import com.uzima.domain.message.model.Conversation;
import com.uzima.domain.message.model.ConversationId;
import com.uzima.domain.user.model.UserId;

import java.util.List;
import java.util.Optional;

/**
 * Port de sortie : Accès à la persistance des conversations.
 * Appartient au domaine. Implémenté par l'infrastructure.
 */
public interface ConversationRepository {

    void save(Conversation conversation);

    Optional<Conversation> findById(ConversationId id);

    /**
     * Trouve la conversation directe entre deux utilisateurs, si elle existe.
     * Utilisé pour éviter les doublons de conversations directes.
     */
    Optional<Conversation> findDirectConversation(UserId userA, UserId userB);

    /**
     * Liste toutes les conversations d'un utilisateur, triées par dernier message.
     */
    List<Conversation> findByParticipant(UserId userId);
}
