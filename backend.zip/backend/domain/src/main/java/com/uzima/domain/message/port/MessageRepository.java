package com.uzima.domain.message.port;

import com.uzima.domain.message.model.ConversationId;
import com.uzima.domain.message.model.Message;
import com.uzima.domain.message.model.MessageId;

import java.util.List;
import java.util.Optional;

/**
 * Port de sortie : Accès à la persistance des messages.
 * Appartient au domaine. Implémenté par l'infrastructure.
 */
public interface MessageRepository {

    void save(Message message);

    Optional<Message> findById(MessageId id);

    /**
     * Récupère les messages d'une conversation, du plus récent au plus ancien.
     */
    List<Message> findByConversationId(ConversationId conversationId, int limit, int offset);

    long countByConversationId(ConversationId conversationId);
}
