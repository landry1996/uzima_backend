package com.uzima.domain.message.service;

import com.uzima.domain.message.model.Conversation;
import com.uzima.domain.message.model.ConversationId;
import com.uzima.domain.message.model.Message;
import com.uzima.domain.message.port.ConversationRepository;
import com.uzima.domain.message.port.MessageRepository;
import com.uzima.domain.shared.DomainException;
import com.uzima.domain.user.model.UserId;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Service de domaine : coordination entre Conversation et MessageRepository.
 *
 * Justification de ce service :
 * Un Aggregate Root ne peut pas dépendre d'un port (repository) — règle DDD.
 * Ce service coordonne les deux ports (ConversationRepository, MessageRepository)
 * pour les opérations qui nécessitent les deux simultanément, sans porter
 * de logique applicative (orchestration, transactions, DTOs).
 *
 * Méthodes utilisées du domaine :
 * - Conversation.canSendMessage()          : contrôle d'accès domaine (participant ?)
 * - Conversation.recentMessages()          : accès à la liste hydratée via loadMessage()
 * - ConversationRepository.findDirectConversation() : déduplication des conversations directes
 * - ConversationRepository.findByParticipant()      : boîte de réception de l'utilisateur
 * - MessageRepository.findByConversationId()         : chargement paginé des messages
 * - MessageRepository.countByConversationId()        : total pour les métadonnées de pagination
 */
public final class ConversationDomainService {

    private final ConversationRepository conversationRepository;
    private final MessageRepository messageRepository;

    public ConversationDomainService(
            ConversationRepository conversationRepository,
            MessageRepository messageRepository
    ) {
        this.conversationRepository = Objects.requireNonNull(conversationRepository,
                "ConversationRepository est obligatoire");
        this.messageRepository = Objects.requireNonNull(messageRepository,
                "MessageRepository est obligatoire");
    }

    /**
     * Charge une conversation hydratée avec ses messages paginés.
     *
     * Contrôle d'accès domaine : Conversation.canSendMessage() vérifie
     * que le demandeur est participant (règle métier, pas applicative).
     * Hydrate l'agrégat via loadMessage(), puis expose via recentMessages().
     *
     * @param conversationId  La conversation à charger
     * @param requestingUser  L'utilisateur demandant l'accès
     * @param limit           Nombre de messages à retourner (pagination)
     * @param offset          Décalage dans la liste de messages (pagination)
     * @return Vue hydratée ou empty si la conversation n'existe pas
     * @throws UnauthorizedConversationAccessException si l'utilisateur n'est pas participant
     */
    public Optional<HydratedConversation> loadWithMessages(
            ConversationId conversationId,
            UserId requestingUser,
            int limit,
            int offset
    ) {
        return conversationRepository.findById(conversationId)
                .map(conversation -> {
                    // Contrôle d'accès via la règle métier canSendMessage()
                    if (!conversation.canSendMessage(requestingUser)) {
                        throw new UnauthorizedConversationAccessException(
                                "L'utilisateur " + requestingUser
                                + " n'est pas participant de la conversation " + conversationId);
                    }

                    // Chargement paginé des messages (findByConversationId + countByConversationId)
                    List<Message> messages = messageRepository.findByConversationId(
                            conversationId, limit, offset);
                    long total = messageRepository.countByConversationId(conversationId);

                    // Hydratation de l'agrégat → recentMessages() devient accessible
                    messages.forEach(conversation::loadMessage);

                    return new HydratedConversation(conversation, conversation.recentMessages(), total);
                });
    }

    /**
     * Vérifie l'existence d'une conversation directe entre deux utilisateurs.
     * Utilise findDirectConversation() pour éviter la création de doublons.
     *
     * @param userA Premier participant
     * @param userB Second participant
     * @return La conversation directe existante, ou empty
     */
    public Optional<Conversation> findDirectConversation(UserId userA, UserId userB) {
        return conversationRepository.findDirectConversation(userA, userB);
    }

    /**
     * Retourne toutes les conversations d'un utilisateur (boîte de réception).
     * Utilise findByParticipant() pour récupérer l'historique complet.
     *
     * @param userId L'utilisateur dont on veut la boîte de réception
     * @return Liste des conversations, triées par dernier message (ordre du repository)
     */
    public List<Conversation> findUserInbox(UserId userId) {
        return conversationRepository.findByParticipant(userId);
    }

    // -------------------------------------------------------------------------
    // Types de retour
    // -------------------------------------------------------------------------

    /**
     * Vue immuable d'une conversation hydratée avec ses messages.
     * recentMessages() expose la liste chargée via loadMessage().
     * totalMessageCount : utilisé par le client pour calculer la pagination.
     */
    public record HydratedConversation(
            Conversation conversation,
            List<Message> recentMessages,
            long totalMessageCount
    ) {}

    // -------------------------------------------------------------------------
    // Exceptions de domaine
    // -------------------------------------------------------------------------

    public static final class UnauthorizedConversationAccessException extends DomainException {
        public UnauthorizedConversationAccessException(String m) { super(m); }
    }
}
