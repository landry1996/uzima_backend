package com.uzima.application.shared.exception;

/**
 * Conflit de données (ex : numéro déjà utilisé, doublon).
 * Traduite en HTTP 409 par le GlobalExceptionHandler.
 */
public class ConflictException extends ApplicationException {

    public ConflictException(String errorCode, String message) {
        super(errorCode, message);
    }
}
