package com.uzima.application.shared.exception;

/**
 * Ressource demandée introuvable (ex : utilisateur, conversation, QR code).
 * Traduite en HTTP 404 par le GlobalExceptionHandler.
 */
public class ResourceNotFoundException extends ApplicationException {

    public ResourceNotFoundException(String resourceType, Object identifier) {
        super(
            resourceType.toUpperCase() + "_NOT_FOUND",
            resourceType + " introuvable : " + identifier
        );
    }
}
