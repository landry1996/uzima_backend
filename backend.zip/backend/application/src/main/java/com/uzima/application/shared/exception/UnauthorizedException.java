package com.uzima.application.shared.exception;

/**
 * Accès non autorisé à une ressource ou opération.
 * Traduite en HTTP 403 par le GlobalExceptionHandler.
 * Différence avec AuthenticationFailedException :
 * - AuthenticationFailedException → identifiants invalides (qui êtes-vous ?)
 * - UnauthorizedException → identifié mais pas autorisé (que pouvez-vous faire ?)
 */
public class UnauthorizedException extends ApplicationException {

    public UnauthorizedException(String message) {
        super("UNAUTHORIZED_ACCESS", message);
    }

    public UnauthorizedException(String errorCode, String message) {
        super(errorCode, message);
    }
}
