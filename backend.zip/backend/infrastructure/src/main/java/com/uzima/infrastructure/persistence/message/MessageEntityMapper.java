package com.uzima.infrastructure.persistence.message;

import com.uzima.domain.message.model.*;
import com.uzima.domain.user.model.UserId;

/**
 * Mapper : Conversion bidirectionnelle entre Message (domaine) et MessageJpaEntity (infrastructure).
 */
public final class MessageEntityMapper {

    private MessageEntityMapper() {}

    public static MessageJpaEntity toJpaEntity(Message message) {
        return MessageJpaEntity.of(
                message.id().value(),
                message.conversationId().value(),
                message.senderId().value(),
                message.content().text(),
                message.type(),
                message.sentAt(),
                message.isDeleted(),
                message.deletedAt().orElse(null)
        );
    }

    public static Message toDomain(MessageJpaEntity entity) {
        return Message.reconstitute(
                MessageId.of(entity.getId()),
                ConversationId.of(entity.getConversationId()),
                UserId.of(entity.getSenderId()),
                MessageContent.of(entity.getContent()),
                entity.getMessageType(),
                entity.getSentAt(),
                entity.isDeleted(),
                entity.getDeletedAt()
        );
    }
}
