package com.uzima.infrastructure.notification;

import com.uzima.application.message.port.out.MessageNotificationPort;
import com.uzima.application.notification.NotificationRouter;
import com.uzima.application.user.port.out.UserRepositoryPort;
import com.uzima.domain.message.model.Message;
import com.uzima.domain.user.model.PresenceStatus;
import com.uzima.domain.user.model.User;
import com.uzima.domain.user.model.UserId;

import java.util.Objects;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Adaptateur : Implémente MessageNotificationPort avec routing basé sur PresenceStatus.
 *
 * Remplace le stub vide dans InfrastructureConfiguration.
 *
 * Principe (Nouveauté 7 - "Respect Automatique États") :
 * 1. Pour chaque destinataire, récupère son PresenceStatus
 * 2. Délègue au NotificationRouter qui sélectionne la bonne Strategy
 * 3. La stratégie choisie livre la notification de façon appropriée
 *
 * L'application ne connaît que MessageNotificationPort.
 * L'infrastructure gère le routing par présence — transparence totale.
 */
public final class PresenceAwareNotificationAdapter implements MessageNotificationPort {

    private static final Logger log = Logger.getLogger(PresenceAwareNotificationAdapter.class.getName());

    private final NotificationRouter router;
    private final UserRepositoryPort userRepository;

    public PresenceAwareNotificationAdapter(
            NotificationRouter router,
            UserRepositoryPort userRepository
    ) {
        this.router = Objects.requireNonNull(router);
        this.userRepository = Objects.requireNonNull(userRepository);
    }

    @Override
    public void notifyNewMessage(Message message, Set<UserId> recipients) {
        Objects.requireNonNull(message);
        Objects.requireNonNull(recipients);

        for (UserId recipientId : recipients) {
            try {
                PresenceStatus status = userRepository.findById(recipientId)
                        .map(User::presenceStatus)
                        .orElse(PresenceStatus.OFFLINE); // par sécurité

                router.route(message, recipientId, status);

            } catch (Exception e) {
                // Ne jamais laisser une erreur de notification bloquer l'envoi du message
                log.warning("[NOTIFICATION] Échec de la notification pour " + recipientId
                        + " : " + e.getMessage());
            }
        }
    }
}
