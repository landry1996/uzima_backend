package com.uzima.infrastructure.notification;

import com.uzima.application.notification.NotificationRoutingStrategy;
import com.uzima.application.notification.PendingNotification;
import com.uzima.domain.user.model.PresenceStatus;
import com.uzima.domain.user.model.UserId;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.logging.Logger;

/**
 * Stratégie : Notification DIFFÉRÉE (batching).
 *
 * Appliquée pour : FOCUSED, TIRED, SILENCE (NotificationPolicy.DEFERRED)
 *
 * Comportement :
 * - Stocke la notification dans une file en mémoire (ConcurrentLinkedQueue)
 *   indexée par queueKey(notification) → "notifications:deferred:{recipientId}"
 * - Livre lors de la prochaine fenêtre batch via drainQueue(recipientId)
 *   (appelé quand l'état de présence repasse à AVAILABLE)
 *
 * Résultat visible par l'expéditeur (Nouveauté 7) :
 * "Marie est concentrée, message livré silencieusement"
 *
 * Note : Pour la production, remplacer la ConcurrentLinkedQueue par un
 * RedisTemplate<String, PendingNotification> en conservant la même interface.
 */
public final class DeferredNotificationStrategy implements NotificationRoutingStrategy {

    private static final Logger log = Logger.getLogger(DeferredNotificationStrategy.class.getName());

    // File en mémoire : clé = queueKey(notification), valeur = file de notifications en attente
    private final ConcurrentHashMap<String, ConcurrentLinkedQueue<PendingNotification>> queues =
            new ConcurrentHashMap<>();

    @Override
    public void route(PendingNotification notification) {
        Objects.requireNonNull(notification);
        String key = queueKey(notification);
        queues.computeIfAbsent(key, k -> new ConcurrentLinkedQueue<>()).add(notification);
        log.info("[DEFERRED] Notification mise en file sous la clé '" + key
                + "' (sera livrée au prochain batch)");
    }

    @Override
    public PresenceStatus.NotificationPolicy supportedPolicy() {
        return PresenceStatus.NotificationPolicy.DEFERRED;
    }

    /**
     * Draine et retourne toutes les notifications en attente pour un utilisateur.
     * Appelé lorsque l'utilisateur repasse à l'état AVAILABLE.
     *
     * @param recipientId L'identifiant du destinataire
     * @return La liste des notifications en attente (dans l'ordre d'arrivée), vide si aucune
     */
    public List<PendingNotification> drainQueue(UserId recipientId) {
        Objects.requireNonNull(recipientId);
        String key = "notifications:deferred:" + recipientId;
        ConcurrentLinkedQueue<PendingNotification> queue = queues.remove(key);
        if (queue == null) {
            return List.of();
        }
        List<PendingNotification> drained = new ArrayList<>(queue);
        log.info("[DEFERRED] " + drained.size() + " notification(s) drainée(s) pour " + recipientId);
        return drained;
    }

    /**
     * Retourne le nombre de notifications en attente pour un utilisateur.
     * Utile pour l'affichage du badge de notifications.
     *
     * @param recipientId L'identifiant du destinataire
     * @return Le nombre de notifications en attente
     */
    public int pendingCount(UserId recipientId) {
        Objects.requireNonNull(recipientId);
        String key = "notifications:deferred:" + recipientId;
        ConcurrentLinkedQueue<PendingNotification> queue = queues.get(key);
        return queue == null ? 0 : queue.size();
    }

    private String queueKey(PendingNotification notification) {
        return "notifications:deferred:" + notification.recipientId();
    }
}
