package com.uzima.infrastructure.notification;

import com.uzima.application.notification.NotificationRoutingStrategy;
import com.uzima.application.notification.PendingNotification;
import com.uzima.domain.user.model.PresenceStatus;

import java.util.Objects;
import java.util.logging.Logger;

/**
 * Stratégie : Notification BLOQUÉE.
 *
 * Appliquée pour : WELLNESS, OFFLINE (NotificationPolicy.BLOCKED)
 *
 * Comportement :
 * - Aucune notification temps réel
 * - Stockage en base (le message reste disponible quand l'utilisateur revient)
 * - En production : la notification sera visible au prochain login/retour en ligne
 *
 * Noteworthy : même BLOCKED stocke le message — l'utilisateur ne perd rien,
 * il verra ses messages non lus à son retour.
 */
public final class BlockedNotificationStrategy implements NotificationRoutingStrategy {

    private static final Logger log = Logger.getLogger(BlockedNotificationStrategy.class.getName());

    @Override
    public void route(PendingNotification notification) {
        Objects.requireNonNull(notification);
        // Message déjà persisté en DB par MessageRepositoryPort.save()
        // Aucune action temps réel — l'utilisateur verra au prochain login
        log.info("[BLOCKED] Notification supprimée pour " + notification.recipientId()
                + " (état: WELLNESS/OFFLINE) — message disponible en DB");
    }

    @Override
    public PresenceStatus.NotificationPolicy supportedPolicy() {
        return PresenceStatus.NotificationPolicy.BLOCKED;
    }
}
