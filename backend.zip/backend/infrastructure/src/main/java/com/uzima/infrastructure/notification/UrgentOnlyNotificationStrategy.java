package com.uzima.infrastructure.notification;

import com.uzima.application.notification.NotificationRoutingStrategy;
import com.uzima.application.notification.PendingNotification;
import com.uzima.domain.user.model.PresenceStatus;

import java.util.Objects;
import java.util.logging.Logger;

/**
 * Stratégie : Notification pour URGENCES UNIQUEMENT.
 *
 * Appliquée pour : TRAVELING, PHYSICAL_ACTIVITY, SLEEPING (NotificationPolicy.URGENT_ONLY)
 *
 * Comportement :
 * - Si la notification est urgente → envoi immédiat
 * - Si la notification est normale → mise en file différée
 *
 * En production, "urgente" = contact prioritaire (famille, contacts marqués "urgence").
 * Cette logique de priorité est dans l'application layer (hors scope ici).
 */
public final class UrgentOnlyNotificationStrategy implements NotificationRoutingStrategy {

    private static final Logger log = Logger.getLogger(UrgentOnlyNotificationStrategy.class.getName());

    private final ImmediateNotificationStrategy immediateStrategy;
    private final DeferredNotificationStrategy deferredStrategy;

    public UrgentOnlyNotificationStrategy(
            ImmediateNotificationStrategy immediateStrategy,
            DeferredNotificationStrategy deferredStrategy
    ) {
        this.immediateStrategy = Objects.requireNonNull(immediateStrategy);
        this.deferredStrategy = Objects.requireNonNull(deferredStrategy);
    }

    @Override
    public void route(PendingNotification notification) {
        Objects.requireNonNull(notification);
        if (notification.isUrgent()) {
            log.info("[URGENT_ONLY] Notification urgente → envoi immédiat pour " + notification.recipientId());
            immediateStrategy.route(notification);
        } else {
            log.info("[URGENT_ONLY] Notification non urgente → mise en file pour " + notification.recipientId());
            deferredStrategy.route(notification);
        }
    }

    @Override
    public PresenceStatus.NotificationPolicy supportedPolicy() {
        return PresenceStatus.NotificationPolicy.URGENT_ONLY;
    }
}
