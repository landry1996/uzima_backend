package com.uzima.infrastructure.notification;

import com.uzima.application.notification.NotificationRoutingStrategy;
import com.uzima.application.notification.PendingNotification;
import com.uzima.domain.user.model.PresenceStatus;

import java.util.Objects;
import java.util.logging.Logger;

/**
 * Stratégie : Notification IMMÉDIATE.
 *
 * Appliquée pour : AVAILABLE, CELEBRATING (NotificationPolicy.NORMAL)
 * Comportement : envoie la notification en temps réel via WebSocket/Socket.IO
 *
 * TODO : Injecter SocketIOServer ou SimpMessagingTemplate
 *        pour l'envoi WebSocket réel en production.
 */
public final class ImmediateNotificationStrategy implements NotificationRoutingStrategy {

    private static final Logger log = Logger.getLogger(ImmediateNotificationStrategy.class.getName());

    // TODO : Injecter le client WebSocket réel (SocketIOServer, etc.)

    @Override
    public void route(PendingNotification notification) {
        Objects.requireNonNull(notification);
        // En production : websocketClient.sendToUser(notification.recipientId(), notification.message())
        log.info("[IMMEDIATE] Notification envoyée à " + notification.recipientId()
                + " pour message " + notification.message().id());
    }

    @Override
    public PresenceStatus.NotificationPolicy supportedPolicy() {
        return PresenceStatus.NotificationPolicy.NORMAL;
    }
}
