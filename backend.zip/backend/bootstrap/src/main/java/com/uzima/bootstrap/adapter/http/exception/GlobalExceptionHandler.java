package com.uzima.bootstrap.adapter.http.exception;

import com.uzima.application.security.BruteForceProtectionService;
import com.uzima.application.shared.exception.ApplicationException;
import com.uzima.application.shared.exception.ConflictException;
import com.uzima.application.shared.exception.ResourceNotFoundException;
import com.uzima.application.shared.exception.UnauthorizedException;
import com.uzima.application.message.GetConversationUseCase;
import com.uzima.application.message.SendMessageUseCase;
import com.uzima.application.message.StartConversationUseCase;
import com.uzima.application.user.AuthenticateUserUseCase;
import com.uzima.application.user.RegisterUserUseCase;
import com.uzima.application.user.UpdateUserProfileUseCase;
import com.uzima.application.user.port.out.PhoneValidationPort;
import com.uzima.domain.shared.DomainException;
import com.uzima.domain.shared.exception.BusinessRuleViolationException;
import com.uzima.domain.user.model.CountryCode;
import com.uzima.domain.user.model.FirstName;
import com.uzima.domain.user.model.LastName;
import com.uzima.domain.user.model.PhoneNumber;
import com.uzima.security.token.port.AccessTokenVerifierPort;
import com.uzima.security.token.usecase.RefreshAccessTokenUseCase;
import com.uzima.infrastructure.shared.exception.DatabaseException;
import com.uzima.infrastructure.shared.exception.ExternalServiceException;
import com.uzima.infrastructure.shared.exception.InfrastructureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Gestionnaire global des exceptions HTTP.
 *
 * Centralise toute la logique de traduction Exception → HTTP.
 * Les contrôleurs n'ont plus de @ExceptionHandler locaux.
 *
 * Hiérarchie de traduction :
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │ DomainException                    → 400 Bad Request / 422          │
 * │   └── BusinessRuleViolationException → 422 Unprocessable Entity     │
 * │   └── InvalidPhoneNumberException   → 400 Bad Request               │
 * │ ApplicationException               → 4xx selon sous-type            │
 * │   └── ResourceNotFoundException    → 404 Not Found                  │
 * │   └── UnauthorizedException        → 403 Forbidden                  │
 * │   └── ConflictException            → 409 Conflict                   │
 * │ AuthenticationFailedException      → 401 Unauthorized               │
 * │ AccountTemporarilyLockedException  → 429 Too Many Requests          │
 * │ InfrastructureException            → 5xx Service Error              │
 * │   └── DatabaseException            → 503 Service Unavailable        │
 * │   └── ExternalServiceException     → 502 Bad Gateway                │
 * │ Validation (@Valid)                → 400 Bad Request                 │
 * │ Exception (catch-all)              → 500 Internal Server Error       │
 * └─────────────────────────────────────────────────────────────────────┘
 *
 * Sécurité : les détails techniques (stack trace, noms internes) ne sont
 * jamais exposés dans la réponse HTTP.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = Logger.getLogger(GlobalExceptionHandler.class.getName());

    // -------------------------------------------------------------------------
    // Exceptions de domaine
    // -------------------------------------------------------------------------

    @ExceptionHandler(BusinessRuleViolationException.class)
    public ResponseEntity<ApiError> handleBusinessRuleViolation(BusinessRuleViolationException ex) {
        log.warning("Règle métier violée [" + ex.ruleCode() + "] : " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY)
                .body(ApiError.of(422, ex.ruleCode(), ex.getMessage()));
    }

    @ExceptionHandler(PhoneNumber.InvalidPhoneNumberException.class)
    public ResponseEntity<ApiError> handleInvalidPhone(PhoneNumber.InvalidPhoneNumberException ex) {
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "INVALID_PHONE_NUMBER", ex.getMessage()));
    }

    @ExceptionHandler(CountryCode.InvalidCountryCodeException.class)
    public ResponseEntity<ApiError> handleInvalidCountry(CountryCode.InvalidCountryCodeException ex) {
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "INVALID_COUNTRY_CODE", ex.getMessage()));
    }

    @ExceptionHandler(FirstName.InvalidFirstNameException.class)
    public ResponseEntity<ApiError> handleInvalidFirstName(FirstName.InvalidFirstNameException ex) {
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "INVALID_FIRST_NAME", ex.getMessage()));
    }

    @ExceptionHandler(LastName.InvalidLastNameException.class)
    public ResponseEntity<ApiError> handleInvalidLastName(LastName.InvalidLastNameException ex) {
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "INVALID_LAST_NAME", ex.getMessage()));
    }

    @ExceptionHandler(PhoneValidationPort.PhoneValidationException.class)
    public ResponseEntity<ApiError> handlePhoneValidation(PhoneValidationPort.PhoneValidationException ex) {
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "PHONE_COUNTRY_MISMATCH", ex.getMessage()));
    }

    @ExceptionHandler(DomainException.class)
    public ResponseEntity<ApiError> handleDomainException(DomainException ex) {
        log.warning("Exception de domaine : " + ex.getMessage());
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "DOMAIN_RULE_VIOLATION", ex.getMessage()));
    }

    // -------------------------------------------------------------------------
    // Exceptions d'application
    // -------------------------------------------------------------------------

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ApiError> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of(404, ex.errorCode(), ex.getMessage()));
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<ApiError> handleUnauthorized(UnauthorizedException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ApiError.of(403, ex.errorCode(), ex.getMessage()));
    }

    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<ApiError> handleConflict(ConflictException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ApiError.of(409, ex.errorCode(), ex.getMessage()));
    }

    @ExceptionHandler(ApplicationException.class)
    public ResponseEntity<ApiError> handleApplicationException(ApplicationException ex) {
        log.warning("Exception applicative [" + ex.errorCode() + "] : " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ApiError.of(400, ex.errorCode(), ex.getMessage()));
    }

    // -------------------------------------------------------------------------
    // Authentification & sécurité
    // -------------------------------------------------------------------------

    @ExceptionHandler(AuthenticateUserUseCase.AuthenticationFailedException.class)
    public ResponseEntity<ApiError> handleAuthFailed(AuthenticateUserUseCase.AuthenticationFailedException ex) {
        // Message GÉNÉRIQUE : ne pas révéler si le compte existe ou non
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(ApiError.of(401, "AUTHENTICATION_FAILED", "Identifiants invalides"));
    }

    @ExceptionHandler(RegisterUserUseCase.PhoneNumberAlreadyUsedException.class)
    public ResponseEntity<ApiError> handlePhoneAlreadyUsed(RegisterUserUseCase.PhoneNumberAlreadyUsedException ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ApiError.of(409, "PHONE_ALREADY_USED", ex.getMessage()));
    }

    @ExceptionHandler(RefreshAccessTokenUseCase.TokenRefreshException.class)
    public ResponseEntity<ApiError> handleTokenRefresh(RefreshAccessTokenUseCase.TokenRefreshException ex) {
        // Même message pour token expiré, inconnu ou compromis (pas de fuite d'info)
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(ApiError.of(401, "TOKEN_REFRESH_FAILED", "Refresh token invalide ou expiré"));
    }

    @ExceptionHandler(AccessTokenVerifierPort.InvalidTokenException.class)
    public ResponseEntity<ApiError> handleInvalidToken(AccessTokenVerifierPort.InvalidTokenException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(ApiError.of(401, "INVALID_ACCESS_TOKEN", "Access token invalide ou expiré"));
    }

    @ExceptionHandler(SendMessageUseCase.SenderNotInConversationException.class)
    public ResponseEntity<ApiError> handleSenderNotInConversation(SendMessageUseCase.SenderNotInConversationException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ApiError.of(403, "SENDER_NOT_IN_CONVERSATION", ex.getMessage()));
    }

    @ExceptionHandler(SendMessageUseCase.VoiceMessageNotAllowedException.class)
    public ResponseEntity<ApiError> handleVoiceNotAllowed(SendMessageUseCase.VoiceMessageNotAllowedException ex) {
        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY)
                .body(ApiError.of(422, "VOICE_MESSAGE_NOT_ALLOWED", ex.getMessage()));
    }

    @ExceptionHandler(GetConversationUseCase.UnauthorizedConversationAccessException.class)
    public ResponseEntity<ApiError> handleUnauthorizedConversation(GetConversationUseCase.UnauthorizedConversationAccessException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ApiError.of(403, "CONVERSATION_ACCESS_DENIED", ex.getMessage()));
    }

    @ExceptionHandler(StartConversationUseCase.UserNotFoundException.class)
    public ResponseEntity<ApiError> handleUserNotFoundForConversation(StartConversationUseCase.UserNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of(404, "USER_NOT_FOUND", ex.getMessage()));
    }

    @ExceptionHandler(UpdateUserProfileUseCase.UserNotFoundException.class)
    public ResponseEntity<ApiError> handleUserNotFoundForProfile(UpdateUserProfileUseCase.UserNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ApiError.of(404, "USER_NOT_FOUND", ex.getMessage()));
    }

    @ExceptionHandler(BruteForceProtectionService.AccountTemporarilyLockedException.class)
    public ResponseEntity<ApiError> handleAccountLocked(
            BruteForceProtectionService.AccountTemporarilyLockedException ex
    ) {
        // HTTP 429 Too Many Requests avec durée de verrouillage dans le message
        return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                .body(ApiError.of(429, "ACCOUNT_TEMPORARILY_LOCKED", ex.getMessage()));
    }

    // -------------------------------------------------------------------------
    // Exceptions d'infrastructure (5xx)
    // -------------------------------------------------------------------------

    @ExceptionHandler(DatabaseException.class)
    public ResponseEntity<ApiError> handleDatabase(DatabaseException ex) {
        // Log technique détaillé côté serveur, message générique côté client
        log.log(Level.SEVERE, "Erreur base de données : " + ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(ApiError.of(503, "DATABASE_ERROR", "Service temporairement indisponible"));
    }

    @ExceptionHandler(ExternalServiceException.class)
    public ResponseEntity<ApiError> handleExternalService(ExternalServiceException ex) {
        log.log(Level.SEVERE, "Service externe [" + ex.serviceName() + "] indisponible : " + ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(ApiError.of(502, "EXTERNAL_SERVICE_ERROR", "Service externe temporairement indisponible"));
    }

    @ExceptionHandler(InfrastructureException.class)
    public ResponseEntity<ApiError> handleInfrastructure(InfrastructureException ex) {
        log.log(Level.SEVERE, "Erreur infrastructure : " + ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiError.of(500, "INFRASTRUCTURE_ERROR", "Erreur interne du serveur"));
    }

    // -------------------------------------------------------------------------
    // Erreurs de validation Bean Validation (@Valid)
    // -------------------------------------------------------------------------

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException ex) {
        String details = ex.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));
        return ResponseEntity.badRequest()
                .body(ApiError.of(400, "VALIDATION_ERROR", details));
    }

    // -------------------------------------------------------------------------
    // Catch-all (défense en profondeur)
    // -------------------------------------------------------------------------

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> handleUnexpected(Exception ex) {
        // Log complet côté serveur
        log.log(Level.SEVERE, "Exception inattendue : " + ex.getMessage(), ex);
        // Message GÉNÉRIQUE côté client (pas de fuite d'information)
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiError.of(500, "INTERNAL_ERROR", "Une erreur interne s'est produite"));
    }
}
