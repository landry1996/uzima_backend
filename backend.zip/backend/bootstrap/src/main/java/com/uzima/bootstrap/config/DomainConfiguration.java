package com.uzima.bootstrap.config;

import com.uzima.application.message.GetConversationUseCase;
import com.uzima.application.message.GetUserConversationsUseCase;
import com.uzima.application.message.SendMessageUseCase;
import com.uzima.application.message.StartConversationUseCase;
import com.uzima.application.message.port.out.ConversationRepositoryPort;
import com.uzima.application.message.port.out.MessageNotificationPort;
import com.uzima.application.message.port.out.MessageRepositoryPort;
import com.uzima.application.qrcode.CreateQrCodeUseCase;
import com.uzima.application.qrcode.GetMyQrCodesUseCase;
import com.uzima.application.qrcode.port.out.QrCodeRepositoryPort;
import com.uzima.application.user.UpdateUserProfileUseCase;
import com.uzima.application.security.BruteForceProtectionService;
import com.uzima.application.security.LoginAttemptRepositoryPort;
import com.uzima.application.user.AuthenticateUserUseCase;
import com.uzima.application.user.RegisterUserUseCase;
import com.uzima.application.user.UpdatePresenceStatusUseCase;
import com.uzima.application.user.port.out.PasswordHasherPort;
import com.uzima.application.user.port.out.PhoneValidationPort;
import com.uzima.application.user.port.out.UserRepositoryPort;
import com.uzima.domain.security.AccountLockoutPolicy;
import com.uzima.domain.shared.TimeProvider;
import com.uzima.infrastructure.security.BcryptPasswordHasher;
import com.uzima.infrastructure.security.JwtAccessTokenGenerator;
import com.uzima.infrastructure.security.JwtAccessTokenVerifier;
import com.uzima.infrastructure.time.SystemTimeProvider;
import com.uzima.security.token.port.AccessTokenGeneratorPort;
import com.uzima.security.token.port.AccessTokenVerifierPort;
import com.uzima.security.token.port.RefreshTokenHasherPort;
import com.uzima.security.token.port.RefreshTokenRepositoryPort;
import com.uzima.security.token.usecase.GenerateTokenPairUseCase;
import com.uzima.security.token.usecase.RefreshAccessTokenUseCase;
import com.uzima.security.token.usecase.RevokeAllTokensUseCase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * Configuration Spring : Câblage de tous les composants (Wiring).
 *
 * Principe DIP visible ici :
 * - Les Use Cases reçoivent des PORTS (interfaces du domaine/application/security)
 * - Les Beans instanciés sont des ADAPTATEURS (implémentations infrastructure)
 * - Changer une implémentation = modifier uniquement ce fichier
 */
@Configuration
public class DomainConfiguration {

    // -------------------------------------------------------------------------
    // Infrastructure - Adapters techniques partagés
    // -------------------------------------------------------------------------

    @Bean
    public TimeProvider timeProvider() {
        return new SystemTimeProvider();
    }

    @Bean
    public PasswordHasherPort passwordHasher() {
        return new BcryptPasswordHasher();
    }

    @Bean
    public AccessTokenGeneratorPort accessTokenGenerator(
            @Value("${uzima.security.jwt.secret}") String secret,
            @Value("${uzima.security.jwt.access-token-expiration-seconds:900}") long expirationSeconds
    ) {
        return new JwtAccessTokenGenerator(secret, Duration.ofSeconds(expirationSeconds));
    }

    @Bean
    public AccessTokenVerifierPort accessTokenVerifier(
            @Value("${uzima.security.jwt.secret}") String secret
    ) {
        return new JwtAccessTokenVerifier(secret);
    }

    // -------------------------------------------------------------------------
    // Sécurité - Politique de verrouillage (domaine pur)
    // -------------------------------------------------------------------------

    @Bean
    public AccountLockoutPolicy accountLockoutPolicy() {
        return new AccountLockoutPolicy();
    }

    @Bean
    public BruteForceProtectionService bruteForceProtectionService(
            AccountLockoutPolicy lockoutPolicy,
            LoginAttemptRepositoryPort loginAttemptRepository,
            TimeProvider timeProvider
    ) {
        return new BruteForceProtectionService(lockoutPolicy, loginAttemptRepository, timeProvider);
    }

    // -------------------------------------------------------------------------
    // Use Cases - Tokens (module security)
    // -------------------------------------------------------------------------

    @Bean
    public GenerateTokenPairUseCase generateTokenPairUseCase(
            AccessTokenGeneratorPort accessTokenGenerator,
            RefreshTokenHasherPort refreshTokenHasher,
            RefreshTokenRepositoryPort refreshTokenRepository,
            TimeProvider timeProvider
    ) {
        return new GenerateTokenPairUseCase(
                accessTokenGenerator, refreshTokenHasher, refreshTokenRepository, timeProvider
        );
    }

    @Bean
    public RefreshAccessTokenUseCase refreshAccessTokenUseCase(
            AccessTokenGeneratorPort accessTokenGenerator,
            RefreshTokenHasherPort refreshTokenHasher,
            RefreshTokenRepositoryPort refreshTokenRepository,
            TimeProvider timeProvider
    ) {
        return new RefreshAccessTokenUseCase(
                accessTokenGenerator, refreshTokenHasher, refreshTokenRepository, timeProvider
        );
    }

    @Bean
    public RevokeAllTokensUseCase revokeAllTokensUseCase(RefreshTokenRepositoryPort refreshTokenRepository) {
        return new RevokeAllTokensUseCase(refreshTokenRepository);
    }

    // -------------------------------------------------------------------------
    // Use Cases - User
    // -------------------------------------------------------------------------

    @Bean
    public RegisterUserUseCase registerUserUseCase(
            UserRepositoryPort userRepository,
            PasswordHasherPort passwordHasher,
            PhoneValidationPort phoneValidator,
            TimeProvider timeProvider
    ) {
        return new RegisterUserUseCase(userRepository, passwordHasher, phoneValidator, timeProvider);
    }

    @Bean
    public AuthenticateUserUseCase authenticateUserUseCase(
            UserRepositoryPort userRepository,
            PasswordHasherPort passwordHasher,
            BruteForceProtectionService bruteForceProtectionService,
            TimeProvider timeProvider
    ) {
        return new AuthenticateUserUseCase(
                userRepository, passwordHasher, bruteForceProtectionService, timeProvider
        );
    }

    @Bean
    public UpdatePresenceStatusUseCase updatePresenceStatusUseCase(
            UserRepositoryPort userRepository,
            TimeProvider timeProvider
    ) {
        return new UpdatePresenceStatusUseCase(userRepository, timeProvider);
    }

    // -------------------------------------------------------------------------
    // Use Cases - Message
    // -------------------------------------------------------------------------

    @Bean
    public SendMessageUseCase sendMessageUseCase(
            ConversationRepositoryPort conversationRepository,
            MessageRepositoryPort messageRepository,
            MessageNotificationPort notificationPort,
            UserRepositoryPort userRepository,
            TimeProvider timeProvider
    ) {
        return new SendMessageUseCase(
                conversationRepository, messageRepository, notificationPort, userRepository, timeProvider
        );
    }

    @Bean
    public GetConversationUseCase getConversationUseCase(
            ConversationRepositoryPort conversationRepository,
            MessageRepositoryPort messageRepository
    ) {
        return new GetConversationUseCase(conversationRepository, messageRepository);
    }

    @Bean
    public StartConversationUseCase startConversationUseCase(
            ConversationRepositoryPort conversationRepository,
            UserRepositoryPort userRepository,
            TimeProvider timeProvider
    ) {
        return new StartConversationUseCase(conversationRepository, userRepository, timeProvider);
    }

    @Bean
    public GetUserConversationsUseCase getUserConversationsUseCase(
            ConversationRepositoryPort conversationRepository
    ) {
        return new GetUserConversationsUseCase(conversationRepository);
    }

    @Bean
    public UpdateUserProfileUseCase updateUserProfileUseCase(UserRepositoryPort userRepository) {
        return new UpdateUserProfileUseCase(userRepository);
    }

    @Bean
    public CreateQrCodeUseCase createQrCodeUseCase(
            QrCodeRepositoryPort qrCodeRepository,
            TimeProvider timeProvider
    ) {
        return new CreateQrCodeUseCase(qrCodeRepository, timeProvider);
    }

    @Bean
    public GetMyQrCodesUseCase getMyQrCodesUseCase(
            QrCodeRepositoryPort qrCodeRepository,
            TimeProvider timeProvider
    ) {
        return new GetMyQrCodesUseCase(qrCodeRepository, timeProvider);
    }
}
