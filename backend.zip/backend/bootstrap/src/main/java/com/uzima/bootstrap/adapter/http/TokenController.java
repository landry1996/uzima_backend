package com.uzima.bootstrap.adapter.http;

import com.uzima.bootstrap.adapter.http.dto.TokenRefreshRequest;
import com.uzima.bootstrap.adapter.http.dto.TokenResponse;
import com.uzima.domain.user.model.UserId;
import com.uzima.security.token.model.TokenPair;
import com.uzima.security.token.usecase.RefreshAccessTokenUseCase;
import com.uzima.security.token.usecase.RevokeAllTokensUseCase;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur HTTP : Gestion des tokens OAuth2-like.
 * Endpoints :
 * - POST /api/auth/token/refresh  → Rotation du refresh token (sans authentification)
 * - POST /api/auth/token/revoke   → Révocation globale (nécessite un access token valide)
 *
 * La protection CSRF n'est pas appliquée ici car les clients mobiles/SPA utilisent des tokens.
 * Les exceptions sont gérées par GlobalExceptionHandler.
 */
@RestController
@RequestMapping("/api/auth/token")
public class TokenController {

    private final RefreshAccessTokenUseCase refreshAccessTokenUseCase;
    private final RevokeAllTokensUseCase revokeAllTokensUseCase;

    public TokenController(
            RefreshAccessTokenUseCase refreshAccessTokenUseCase,
            RevokeAllTokensUseCase revokeAllTokensUseCase
    ) {
        this.refreshAccessTokenUseCase = refreshAccessTokenUseCase;
        this.revokeAllTokensUseCase = revokeAllTokensUseCase;
    }

    /**
     * Rotation du refresh token.
     * Échange un refresh token valide contre une nouvelle paire access+refresh.
     * L'ancien refresh token est immédiatement révoqué.
     * Si le token présenté est déjà révoqué → replay attack → toute la famille est révoquée.
     *
     * POST /api/auth/token/refresh
     */
    @PostMapping("/refresh")
    public ResponseEntity<TokenResponse> refresh(@Valid @RequestBody TokenRefreshRequest request) {
        TokenPair tokenPair = refreshAccessTokenUseCase.execute(request.refreshToken());
        return ResponseEntity.ok(TokenResponse.from(tokenPair));
    }

    /**
     * Révocation globale (logout de tous les appareils).
     * Nécessite un access token valide dans Authorization: Bearer.
     * Tous les refresh tokens actifs de l'utilisateur sont révoqués.
     *
     * POST /api/auth/token/revoke
     */
    @PostMapping("/revoke")
    public ResponseEntity<Void> revokeAll(@AuthenticationPrincipal String userId) {
        revokeAllTokensUseCase.execute(UserId.of(userId));
        return ResponseEntity.noContent().build();
    }
}
