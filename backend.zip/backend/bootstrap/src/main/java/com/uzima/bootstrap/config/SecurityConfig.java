package com.uzima.bootstrap.config;

import com.uzima.bootstrap.adapter.http.security.JwtAuthenticationFilter;
import com.uzima.security.token.port.AccessTokenVerifierPort;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Configuration Spring Security : Stateless JWT.
 *
 * Politique :
 * - STATELESS : pas de session HTTP (chaque requête est auto-portante via JWT)
 * - CSRF désactivé (inutile pour les APIs stateless avec tokens)
 * - Endpoints publics : /api/auth/login, /api/auth/register, /api/auth/token/refresh
 * - Tous les autres endpoints requièrent un access token valide
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            AccessTokenVerifierPort tokenVerifier
    ) throws Exception {
        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(tokenVerifier);

        http
            .csrf(AbstractHttpConfigurer::disable)
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    "/api/auth/login",
                    "/api/auth/register",
                    "/api/auth/token/refresh"
                ).permitAll()
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
