package com.uzima.bootstrap.adapter.http.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Filtre HTTP : Rate Limiting par adresse IP.
 *
 * Double protection contre la force brute :
 * 1. BruteForceProtectionService : par identifiant (numéro de téléphone)
 * 2. RateLimitingFilter           : par adresse IP (couche HTTP)
 *
 * Algorithme : fenêtre glissante (sliding window counter)
 * - Max 20 requêtes par minute sur /api/auth/**
 * - Réponse HTTP 429 si dépassement, avec header Retry-After
 *
 * Sécurité :
 * - L'IP réelle est extraite du header X-Forwarded-For (reverse proxy)
 * - En cas d'IP invalide → IP "unknown" (sécurité par défaut)
 * - Aucune information interne dans la réponse 429
 *
 * TODO Production :
 * - Remplacer par Redis pour le rate limiting cross-instances
 * - Intégrer avec un WAF (Web Application Firewall)
 * - Configurer les limites via application.yml
 */
public final class RateLimitingFilter extends OncePerRequestFilter {

    private static final int MAX_REQUESTS_PER_WINDOW = 20;
    private static final long WINDOW_DURATION_MS = 60_000L; // 1 minute
    private static final String AUTH_PATH_PREFIX = "/api/auth";

    // Compteurs par IP : (ip → [count, windowStart])
    private final Map<String, long[]> requestCounts = new ConcurrentHashMap<>();

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain
    ) throws ServletException, IOException {

        // Appliquer uniquement sur les endpoints d'authentification
        if (!request.getRequestURI().startsWith(AUTH_PATH_PREFIX)) {
            chain.doFilter(request, response);
            return;
        }

        String clientIp = extractClientIp(request);
        long now = Instant.now().toEpochMilli();

        if (isRateLimitExceeded(clientIp, now)) {
            sendRateLimitResponse(response);
            return;
        }

        chain.doFilter(request, response);
    }

    private boolean isRateLimitExceeded(String clientIp, long now) {
        long[] data = requestCounts.compute(clientIp, (ip, existing) -> {
            if (existing == null || now - existing[1] > WINDOW_DURATION_MS) {
                // Nouvelle fenêtre
                return new long[]{1, now};
            }
            // Incrémenter dans la fenêtre courante
            existing[0]++;
            return existing;
        });

        return data[0] > MAX_REQUESTS_PER_WINDOW;
    }

    private void sendRateLimitResponse(HttpServletResponse response) throws IOException {
        response.setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setHeader("Retry-After", "60");
        response.getWriter().write("""
                {"status":429,"errorCode":"RATE_LIMIT_EXCEEDED",
                 "message":"Trop de tentatives. Réessayez dans 60 secondes."}
                """);
    }

    private String extractClientIp(HttpServletRequest request) {
        // Support des reverse proxies (nginx, load balancer)
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            // X-Forwarded-For peut contenir plusieurs IPs : "client, proxy1, proxy2"
            return forwarded.split(",")[0].strip();
        }
        String realIp = request.getHeader("X-Real-IP");
        if (realIp != null && !realIp.isBlank()) {
            return realIp.strip();
        }
        return request.getRemoteAddr() != null ? request.getRemoteAddr() : "unknown";
    }
}
