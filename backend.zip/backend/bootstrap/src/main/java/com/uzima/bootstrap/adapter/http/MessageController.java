package com.uzima.bootstrap.adapter.http;

import com.uzima.application.message.GetConversationUseCase;
import com.uzima.application.message.SendMessageUseCase;
import com.uzima.application.message.port.in.GetConversationQuery;
import com.uzima.application.message.port.in.SendMessageCommand;
import com.uzima.bootstrap.adapter.http.dto.SendMessageRequest;
import com.uzima.domain.message.model.ConversationId;
import com.uzima.domain.message.model.Message;
import com.uzima.domain.user.model.UserId;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

/**
 * Adaptateur HTTP entrant : Messagerie.
 *
 * Traduit les requêtes HTTP en commandes/requêtes applicatives.
 * Pas de logique métier ici.
 */
@RestController
@RequestMapping("/api/conversations")
public class MessageController {

    private final SendMessageUseCase sendMessageUseCase;
    private final GetConversationUseCase getConversationUseCase;

    public MessageController(
            SendMessageUseCase sendMessageUseCase,
            GetConversationUseCase getConversationUseCase
    ) {
        this.sendMessageUseCase = Objects.requireNonNull(sendMessageUseCase);
        this.getConversationUseCase = Objects.requireNonNull(getConversationUseCase);
    }

    /**
     * POST /api/conversations/{conversationId}/messages
     * Envoie un message dans une conversation.
     *
     * Note : Dans une vraie implémentation, l'UserId de l'expéditeur
     * est extrait du token JWT via le SecurityContext, pas du body.
     */
    @PostMapping("/{conversationId}/messages")
    public ResponseEntity<MessageResponse> sendMessage(
            @PathVariable String conversationId,
            @RequestHeader("X-User-Id") String senderId, // En prod : extrait du JWT
            @Valid @RequestBody SendMessageRequest request
    ) {
        var command = new SendMessageCommand(
                ConversationId.of(conversationId),
                UserId.of(senderId),
                request.content()
        );
        Message message = sendMessageUseCase.execute(command);
        return ResponseEntity.ok(MessageResponse.from(message));
    }

    /**
     * GET /api/conversations/{conversationId}/messages
     * Récupère les messages d'une conversation (paginés).
     */
    @GetMapping("/{conversationId}/messages")
    public ResponseEntity<List<MessageResponse>> getMessages(
            @PathVariable String conversationId,
            @RequestHeader("X-User-Id") String requesterId, // En prod : extrait du JWT
            @RequestParam(defaultValue = "20") int limit,
            @RequestParam(defaultValue = "0") int offset
    ) {
        var query = new GetConversationQuery(
                ConversationId.of(conversationId),
                UserId.of(requesterId),
                limit,
                offset
        );
        var view = getConversationUseCase.execute(query);
        List<MessageResponse> responses = view.messages().stream()
                .map(MessageResponse::from)
                .toList();
        return ResponseEntity.ok(responses);
    }

    // DTO de réponse
    public record MessageResponse(
            String id,
            String conversationId,
            String senderId,
            String content,
            String type,
            Instant sentAt,
            boolean deleted
    ) {
        public static MessageResponse from(Message message) {
            return new MessageResponse(
                    message.id().toString(),
                    message.conversationId().toString(),
                    message.senderId().toString(),
                    message.isDeleted() ? null : message.content().text(),
                    message.type().name(),
                    message.sentAt(),
                    message.isDeleted()
            );
        }
    }
}
