package com.uzima.bootstrap.config;

import com.uzima.application.message.port.out.ConversationRepositoryPort;
import com.uzima.application.message.port.out.MessageNotificationPort;
import com.uzima.application.message.port.out.MessageRepositoryPort;
import com.uzima.application.notification.NotificationRouter;
import com.uzima.application.notification.NotificationRoutingStrategy;
import com.uzima.application.security.LoginAttemptRepositoryPort;
import com.uzima.application.qrcode.port.out.QrCodeRepositoryPort;
import com.uzima.application.user.port.out.PhoneValidationPort;
import com.uzima.application.user.port.out.UserRepositoryPort;
import com.uzima.bootstrap.adapter.http.security.RateLimitingFilter;
import com.uzima.infrastructure.notification.*;
import com.uzima.infrastructure.persistence.message.MessageRepositoryAdapter;
import com.uzima.infrastructure.persistence.message.SpringDataMessageRepository;
import com.uzima.infrastructure.persistence.token.JpaRefreshTokenRepositoryAdapter;
import com.uzima.infrastructure.persistence.token.SpringDataRefreshTokenRepository;
import com.uzima.infrastructure.persistence.user.SpringDataUserRepository;
import com.uzima.infrastructure.persistence.user.UserRepositoryAdapter;
import com.uzima.infrastructure.security.InMemoryLoginAttemptRepository;
import com.uzima.infrastructure.security.LibPhoneNumberAdapter;
import com.uzima.infrastructure.security.SecureRefreshTokenHasher;
import com.uzima.security.token.port.RefreshTokenHasherPort;
import com.uzima.security.token.port.RefreshTokenRepositoryPort;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Configuration Spring : Instanciation des adaptateurs d'infrastructure.
 *
 * Inclut :
 * - Repositories (JPA)
 * - Notification (Strategy pattern câblé ici)
 * - Sécurité (phone validation, token storage, rate limiting)
 */
@Configuration
public class InfrastructureConfiguration {

    // -------------------------------------------------------------------------
    // Persistance - Users
    // -------------------------------------------------------------------------

    @Bean
    public UserRepositoryPort userRepositoryPort(SpringDataUserRepository springDataUserRepository) {
        return new UserRepositoryAdapter(springDataUserRepository);
    }

    @Bean
    public MessageRepositoryPort messageRepositoryPort(SpringDataMessageRepository springDataMessageRepository) {
        return new MessageRepositoryAdapter(springDataMessageRepository);
    }

    @Bean
    public ConversationRepositoryPort conversationRepositoryPort() {
        // TODO : implémenter ConversationRepositoryAdapter avec JPA
        throw new UnsupportedOperationException("ConversationRepositoryAdapter non encore implémenté");
    }

    @Bean
    public QrCodeRepositoryPort qrCodeRepositoryPort() {
        // TODO : implémenter QrCodeRepositoryAdapter avec JPA
        throw new UnsupportedOperationException("QrCodeRepositoryAdapter non encore implémenté");
    }

    // -------------------------------------------------------------------------
    // Persistance - Refresh Tokens
    // -------------------------------------------------------------------------

    @Bean
    public RefreshTokenRepositoryPort refreshTokenRepositoryPort(
            SpringDataRefreshTokenRepository springDataRefreshTokenRepository
    ) {
        return new JpaRefreshTokenRepositoryAdapter(springDataRefreshTokenRepository);
    }

    // -------------------------------------------------------------------------
    // Sécurité - Phone validation (libphonenumber)
    // -------------------------------------------------------------------------

    @Bean
    public PhoneValidationPort phoneValidationPort() {
        return new LibPhoneNumberAdapter();
    }

    // -------------------------------------------------------------------------
    // Sécurité - Refresh Token Hasher
    // -------------------------------------------------------------------------

    @Bean
    public RefreshTokenHasherPort refreshTokenHasherPort() {
        return new SecureRefreshTokenHasher();
    }

    // -------------------------------------------------------------------------
    // Sécurité - Brute force (login attempts)
    // -------------------------------------------------------------------------

    @Bean
    public LoginAttemptRepositoryPort loginAttemptRepositoryPort() {
        // Dev/Test : in-memory. Production : remplacer par RedisLoginAttemptRepository
        return new InMemoryLoginAttemptRepository();
    }

    // -------------------------------------------------------------------------
    // Notification (Strategy pattern)
    // -------------------------------------------------------------------------

    @Bean
    public ImmediateNotificationStrategy immediateNotificationStrategy() {
        return new ImmediateNotificationStrategy();
    }

    @Bean
    public DeferredNotificationStrategy deferredNotificationStrategy() {
        return new DeferredNotificationStrategy();
    }

    @Bean
    public BlockedNotificationStrategy blockedNotificationStrategy() {
        return new BlockedNotificationStrategy();
    }

    @Bean
    public UrgentOnlyNotificationStrategy urgentOnlyNotificationStrategy(
            ImmediateNotificationStrategy immediate,
            DeferredNotificationStrategy deferred
    ) {
        return new UrgentOnlyNotificationStrategy(immediate, deferred);
    }

    @Bean
    public NotificationRouter notificationRouter(
            ImmediateNotificationStrategy immediate,
            DeferredNotificationStrategy deferred,
            UrgentOnlyNotificationStrategy urgentOnly,
            BlockedNotificationStrategy blocked
    ) {
        List<NotificationRoutingStrategy> strategies = List.of(immediate, deferred, urgentOnly, blocked);
        return new NotificationRouter(strategies, immediate);
    }

    @Bean
    public MessageNotificationPort messageNotificationPort(
            NotificationRouter router,
            UserRepositoryPort userRepositoryPort
    ) {
        return new PresenceAwareNotificationAdapter(router, userRepositoryPort);
    }

    // -------------------------------------------------------------------------
    // HTTP - Rate limiting
    // -------------------------------------------------------------------------

    @Bean
    public FilterRegistrationBean<RateLimitingFilter> rateLimitingFilter() {
        FilterRegistrationBean<RateLimitingFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new RateLimitingFilter());
        registration.addUrlPatterns("/api/auth/*");
        registration.setOrder(1);
        registration.setName("rateLimitingFilter");
        return registration;
    }
}
